import { createApp } from './app.js';
import { config } from './config.js';
import { createJsonRepo } from './repo/jsonRepo.js';

const repo = await createJsonRepo(config.dataFile);
const app = createApp({ repo, uploadsDir: config.uploadsDir, clientDist: config.clientDist });

app.listen(config.port, () => {
  console.log(`Сервер запущен: http://localhost:${config.port}`);
  console.log(`Данные: ${config.dataFile}`);
});
