import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Настройки читаются из переменных окружения; необязательный файл .env подхватывается автоматически.
try { process.loadEnvFile(); } catch { /* файла .env нет — используем значения по умолчанию */ }

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

export const config = {
  port: Number(process.env.PORT) || 3001,
  dataFile: process.env.DATA_FILE || path.join(root, 'data', 'db.json'),
  uploadsDir: process.env.UPLOADS_DIR || path.join(root, 'uploads'),
  // Если клиент собран (npm run build в папке client), сервер отдаёт и его: сайт и API с одного адреса.
  clientDist: process.env.CLIENT_DIST || path.resolve(root, '..', 'client', 'dist')
};
