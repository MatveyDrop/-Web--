# ТЕМП — сайт по продаже станков

Две части: клиент на React (папка `client`) и сервер на Node.js + Express (папка `server`). Данные хранятся в PostgreSQL.

## Запуск (нужны Node.js и PostgreSQL)

### 1. База данных

Вариант А — Postgres.app (Mac): скачать с postgresapp.com, перетащить в «Программы», открыть и нажать Initialize / Start. Сервер слушает порт 5432.

Вариант Б — Docker: в корне проекта выполнить `docker compose up -d`, затем создать `server/.env` из `server/.env.example` и раскомментировать строку `DATABASE_URL` для Docker.

### 2. Сервер и клиент

Два окна Терминала.

```
# окно 1 — сервер
cd server
npm install
npm run db:setup     # создаёт базу temp, таблицы и наполняет данными
npm start            # http://localhost:3001

# окно 2 — клиент
cd client
npm install
npm run dev          # http://localhost:5173
```

Сайт открывается по адресу `http://localhost:5173`. Запросы к `/api` и `/uploads` Vite передаёт серверу.

`npm run db:setup` можно запускать повторно: если данные уже есть, наполнение пропускается. `npm run db:reset` удаляет таблицы и создаёт заново с исходными данными.

## База данных

Таблицы: `users`, `machine_types`, `machine_conditions`, `machines`, `machine_specs` (характеристики станка, связь 1:N), `sessions`. Схема — `server/db/schema.sql`, начальные данные — `server/src/seed-data.js`. Все запросы параметризованные.

## Вход для сотрудников

| Роль | Логин | Пароль |
|------|-------|--------|
| Администратор | admin | admin123 |
| Менеджер | manager | manager123 |
| Менеджер | victoria | victoria123 |

Администратор видит и правит все объявления, менеджер — только свои.

## API

| Метод | Адрес | Доступ | Что делает |
|-------|-------|--------|-----------|
| GET | /api/health | все | проверка, что сервер работает |
| GET | /api/machines | все | список станков |
| GET | /api/machines/:id | все | один станок |
| POST | /api/machines | вошедшие | создать объявление |
| PUT | /api/machines/:id | автор или администратор | изменить |
| DELETE | /api/machines/:id | автор или администратор | удалить |
| POST | /api/auth/login | все | вход, возвращает токен |
| GET | /api/auth/me | вошедшие | кто я |
| POST | /api/auth/logout | вошедшие | выход |

Токен передаётся в заголовке `Authorization: Bearer <токен>`.

## Тесты сервера

```
cd server
npm test
```

Тесты на PostgreSQL запускаются, если задана тестовая база (она очищается!):

```
TEST_DATABASE_URL=postgresql://localhost:5432/temp_test npm test
```

## Версии

Версии по лабораторным помечены тегами: `pr2` — HTML, `pr3` — CSS, `pr4` — Bootstrap, `pr5` — JavaScript, `pr6` — React, `pr7` — серверная часть, `pr8` — база данных PostgreSQL.
