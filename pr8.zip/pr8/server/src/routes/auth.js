import express from 'express';
import { verifyPassword, hashPassword } from '../auth/passwords.js';
import { requireAuth } from '../middleware/auth.js';
import { wrap } from '../middleware/common.js';
import { validateLogin } from '../validation.js';

// Хеш для сравнения, когда пользователя с таким логином нет: время ответа не выдаёт, существует ли логин.
const dummyHash = await hashPassword('dummy-password');

export function authRouter(repo) {
  const router = express.Router();

  router.post('/login', wrap(async (req, res) => {
    const creds = validateLogin(req.body);
    if (!creds) return res.status(400).json({ error: 'Укажите логин и пароль' });

    const user = await repo.findUserByLogin(creds.login);
    const ok = await verifyPassword(creds.password, user ? user.passwordHash : dummyHash);
    if (!user || !ok) return res.status(401).json({ error: 'Неверный логин или пароль' });

    const token = await repo.createSession(user.id);
    return res.json({ token, user: { id: user.id, login: user.login, name: user.name, role: user.role } });
  }));

  router.get('/me', requireAuth, (req, res) => {
    res.json({ user: req.user });
  });

  router.post('/logout', requireAuth, wrap(async (req, res) => {
    await repo.deleteSession(req.token);
    res.status(204).end();
  }));

  return router;
}
