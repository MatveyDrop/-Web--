import express from 'express';
import { canModify, requireAuth } from '../middleware/auth.js';
import { wrap } from '../middleware/common.js';
import { isDataUrl, saveImage } from '../uploads.js';
import { parseId, validateMachine } from '../validation.js';

export function machinesRouter(repo, { uploadsDir }) {
  const router = express.Router();

  // Если пришло новое фото (data URL), сохраняем его файлом и заменяем в данных на адрес файла.
  async function prepare(body) {
    const { value, errors, valid } = validateMachine(body);
    if (!valid) return { errors };
    if (isDataUrl(value.image)) value.image = await saveImage(value.image, uploadsDir);
    return { value };
  }

  router.get('/', wrap(async (req, res) => {
    res.json(await repo.listMachines());
  }));

  router.get('/:id', wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const machine = id && await repo.getMachine(id);
    if (!machine) return res.status(404).json({ error: 'Станок не найден' });
    return res.json(machine);
  }));

  router.post('/', requireAuth, wrap(async (req, res) => {
    const { value, errors } = await prepare(req.body);
    if (errors) return res.status(400).json({ error: 'Проверьте поля формы', fields: errors });
    const machine = await repo.createMachine(value, req.user.id);
    return res.status(201).json(machine);
  }));

  router.put('/:id', requireAuth, wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const existing = id && await repo.getMachine(id);
    if (!existing) return res.status(404).json({ error: 'Станок не найден' });
    if (!canModify(req.user, existing)) return res.status(403).json({ error: 'Это чужое объявление' });

    const { value, errors } = await prepare(req.body);
    if (errors) return res.status(400).json({ error: 'Проверьте поля формы', fields: errors });
    return res.json(await repo.updateMachine(id, value));
  }));

  router.delete('/:id', requireAuth, wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const existing = id && await repo.getMachine(id);
    if (!existing) return res.status(404).json({ error: 'Станок не найден' });
    if (!canModify(req.user, existing)) return res.status(403).json({ error: 'Это чужое объявление' });

    await repo.deleteMachine(id);
    return res.status(204).end();
  }));

  return router;
}
