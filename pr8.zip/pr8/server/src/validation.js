import { CONDITIONS, TYPES } from './constants.js';

// Те же правила, что и в форме на клиенте. Проверка на клиенте нужна для удобства,
// а на сервере — для безопасности: запрос можно отправить и мимо формы.

const IMAGE_PATH = /^\/uploads\/[A-Za-z0-9._-]+$/;
const DATA_URL = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;

const isString = (v) => typeof v === 'string';

export function validateMachine(body) {
  const errors = {};
  const b = body && typeof body === 'object' ? body : {};

  const title = isString(b.title) ? b.title.trim() : '';
  if (title.length < 3) errors.title = 'Название: минимум 3 символа';
  if (title.length > 120) errors.title = 'Название: максимум 120 символов';

  if (!TYPES.includes(b.type)) errors.type = 'Неизвестный тип станка';
  if (!CONDITIONS.includes(b.condition)) errors.condition = 'Неизвестное состояние';

  const region = isString(b.region) ? b.region.trim() : '';
  if (region.length < 2 || region.length > 120) errors.region = 'Регион: от 2 до 120 символов';

  let price = null;
  if (b.price !== null && b.price !== undefined) {
    if (!Number.isInteger(b.price) || b.price <= 0 || b.price > 1_000_000_000) {
      errors.price = 'Цена должна быть целым числом больше нуля';
    } else {
      price = b.price;
    }
  }

  const email = isString(b.email) ? b.email.trim() : '';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 120) errors.email = 'Некорректный email';

  const phone = isString(b.phone) ? b.phone.trim() : '';
  const digits = phone.replace(/\D/g, '');
  if (!/^[\d\s()+-]+$/.test(phone) || digits.length !== 11 || !['7', '8'].includes(digits[0])) {
    errors.phone = 'Телефон в формате +7 (999) 123-45-67';
  }

  let image = null;
  if (b.image) {
    if (isString(b.image) && (IMAGE_PATH.test(b.image) || DATA_URL.test(b.image))) image = b.image;
    else errors.image = 'Некорректное изображение';
  }

  const description = isString(b.description) ? b.description.trim().slice(0, 2000) : undefined;

  const value = { title, type: b.type, condition: b.condition, region, price, email, phone, image };
  if (description !== undefined) value.description = description;
  return { value, errors, valid: Object.keys(errors).length === 0 };
}

export function validateLogin(body) {
  const b = body && typeof body === 'object' ? body : {};
  if (!isString(b.login) || !isString(b.password) || !b.login.trim() || !b.password) {
    return null;
  }
  return { login: b.login.trim(), password: b.password };
}

export function parseId(raw) {
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 ? n : null;
}
