// Превращает типичные ошибки подключения к базе в понятные подсказки.
export function explainDbError(err, databaseUrl) {
  const safeUrl = String(databaseUrl).replace(/:\/\/([^:@/]+):[^@]*@/, '://$1:***@');
  switch (err.code) {
    case 'ECONNREFUSED':
      return `Не удалось подключиться к PostgreSQL (${safeUrl}). Запущена ли база? См. раздел «База данных» в README.`;
    case '28P01':
    case '28000':
      return `PostgreSQL отклонил логин или пароль (${safeUrl}). Проверьте DATABASE_URL в файле server/.env.`;
    case '3D000':
      return 'Базы данных ещё нет. Выполните в папке server: npm run db:setup';
    case '42P01':
      return 'В базе нет таблиц. Выполните в папке server: npm run db:setup';
    default:
      return `Ошибка базы данных: ${err.message}`;
  }
}
