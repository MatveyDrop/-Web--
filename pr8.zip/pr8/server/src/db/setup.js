import fs from 'node:fs';
import pg from 'pg';
import { hashPassword } from '../auth/passwords.js';
import { CONDITIONS_SEED, MACHINES_SEED, TYPES_SEED, USERS_SEED } from '../seed-data.js';

const schemaFile = new URL('../../db/schema.sql', import.meta.url);

// Подключение к служебной базе postgres на том же сервере: через неё создаётся наша база.
function adminUrl(databaseUrl) {
  const url = new URL(databaseUrl);
  url.pathname = '/postgres';
  return url.toString();
}

function databaseName(databaseUrl) {
  const name = decodeURIComponent(new URL(databaseUrl).pathname.slice(1));
  if (!/^[A-Za-z0-9_]+$/.test(name)) throw new Error(`Недопустимое имя базы данных: «${name}»`);
  return name;
}

async function ensureDatabase(databaseUrl) {
  const name = databaseName(databaseUrl);
  const admin = new pg.Client({ connectionString: adminUrl(databaseUrl) });
  await admin.connect();
  try {
    const found = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [name]);
    if (found.rows.length === 0) {
      await admin.query(`CREATE DATABASE "${name}"`);   // имя базы нельзя передать параметром, поэтому проверено выше
      return true;
    }
    return false;
  } finally {
    await admin.end();
  }
}

async function seed(client) {
  await client.query('BEGIN');
  try {
    for (const [code, label] of TYPES_SEED) {
      await client.query('INSERT INTO machine_types (code, label) VALUES ($1, $2)', [code, label]);
    }
    for (const [code, label] of CONDITIONS_SEED) {
      await client.query('INSERT INTO machine_conditions (code, label) VALUES ($1, $2)', [code, label]);
    }

    const userIds = {};
    for (const u of USERS_SEED) {
      const res = await client.query(
        'INSERT INTO users (login, password_hash, name, role) VALUES ($1, $2, $3, $4) RETURNING id',
        [u.login, await hashPassword(u.password), u.name, u.role]
      );
      userIds[u.login] = res.rows[0].id;
    }

    for (const m of MACHINES_SEED) {
      await client.query(
        `INSERT INTO machines (id, title, type_code, condition_code, region, price, image, description, email, phone, author_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [m.id, m.title, m.type, m.condition, m.region, m.price, m.image, m.description, m.email, m.phone, userIds[m.authorLogin], m.createdAt]
      );
      for (const [i, spec] of m.specs.entries()) {
        await client.query(
          'INSERT INTO machine_specs (machine_id, sort_order, name, value) VALUES ($1, $2, $3, $4)',
          [m.id, i + 1, spec.name, spec.value]
        );
      }
    }

    // Станки добавлены с готовыми номерами, поэтому счётчик нужно подвинуть, иначе новый станок получит занятый номер.
    await client.query(`SELECT setval(pg_get_serial_sequence('machines', 'id'), (SELECT max(id) FROM machines))`);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  }
}

// 1) создаёт базу, если её нет; 2) создаёт таблицы; 3) заполняет их, если они пустые.
// С reset: true таблицы сначала удаляются, и всё создаётся заново.
export async function setupDatabase({ databaseUrl, reset = false, log = () => {} }) {
  if (await ensureDatabase(databaseUrl)) log(`База данных «${databaseName(databaseUrl)}» создана`);

  const client = new pg.Client({ connectionString: databaseUrl });
  await client.connect();
  try {
    if (reset) {
      await client.query('DROP TABLE IF EXISTS sessions, machine_specs, machines, users, machine_conditions, machine_types CASCADE');
      log('Старые таблицы удалены');
    }
    await client.query(fs.readFileSync(schemaFile, 'utf8'));
    log('Таблицы созданы');

    const { rows } = await client.query('SELECT count(*)::int AS count FROM users');
    if (rows[0].count === 0) {
      await seed(client);
      log(`Данные добавлены: ${USERS_SEED.length} пользователя, ${MACHINES_SEED.length} станков`);
    } else {
      log('Данные уже есть, наполнение пропущено (для чистого запуска: npm run db:reset)');
    }
  } finally {
    await client.end();
  }
}
