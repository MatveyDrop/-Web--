import { randomUUID } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const MAX_BYTES = 2 * 1024 * 1024;

// Определяем формат по первым байтам файла, а не по тому, что написал клиент.
function detectExtension(buf) {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return '.jpg';
  if (buf.length > 8 && buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return '.png';
  if (buf.length > 12 && buf.subarray(0, 4).toString() === 'RIFF' && buf.subarray(8, 12).toString() === 'WEBP') return '.webp';
  return null;
}

// Принимает «data:image/...;base64,...», сохраняет файл в uploads и возвращает адрес вида /uploads/имя.jpg
export async function saveImage(dataUrl, uploadsDir) {
  const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
  const buf = Buffer.from(base64, 'base64');
  if (buf.length > MAX_BYTES) {
    const err = new Error('Фото больше 2 МБ');
    err.status = 413;
    throw err;
  }
  const ext = detectExtension(buf);
  if (!ext) {
    const err = new Error('Файл не похож на изображение');
    err.status = 400;
    throw err;
  }
  await fs.mkdir(uploadsDir, { recursive: true });
  const name = `${randomUUID()}${ext}`;
  await fs.writeFile(path.join(uploadsDir, name), buf);
  return `/uploads/${name}`;
}

export const isDataUrl = (value) => typeof value === 'string' && value.startsWith('data:');
