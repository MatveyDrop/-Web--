export const TYPES = ['milling', 'lathe', 'slotting', 'drilling'];
export const CONDITIONS = ['used', 'refurbished', 'new'];
export const ROLES = ['admin', 'manager'];
