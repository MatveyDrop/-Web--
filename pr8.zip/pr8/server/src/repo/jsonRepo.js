import { randomBytes } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { hashPassword } from '../auth/passwords.js';
import { MACHINES_SEED, USERS_SEED } from '../seed-data.js';

// Хранилище в одном JSON-файле. Используется в лабе 7 и в тестах;
// в лабе 8 основное хранилище — PostgreSQL (repo/pgRepo.js), интерфейс у них одинаковый.

const publicUser = ({ id, login, name, role }) => ({ id, login, name, role });

async function buildInitialState() {
  const users = [];
  for (const [i, u] of USERS_SEED.entries()) {
    users.push({ id: i + 1, login: u.login, name: u.name, role: u.role, passwordHash: await hashPassword(u.password) });
  }
  const idOf = (login) => users.find((u) => u.login === login).id;
  const machines = MACHINES_SEED.map(({ authorLogin, ...m }) => ({ ...m, authorId: idOf(authorLogin) }));
  return { users, machines };
}

export async function createJsonRepo(file) {
  let state;
  if (fs.existsSync(file)) {
    state = JSON.parse(fs.readFileSync(file, 'utf8'));
  } else {
    state = await buildInitialState();
    persist();
  }
  const sessions = new Map();      // token -> userId; в памяти, после перезапуска сервера нужно войти заново

  function persist() {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(state, null, 2));
    fs.renameSync(tmp, file);       // запись через временный файл: при сбое старый файл не повредится
  }

  const authorName = (id) => state.users.find((u) => u.id === id)?.name ?? '';
  const view = (m) => ({ ...m, specs: m.specs ?? [], image: m.image ?? null, author: authorName(m.authorId) });

  return {
    async listMachines() {
      return state.machines.map(view).sort((a, b) => a.id - b.id);
    },

    async getMachine(id) {
      const m = state.machines.find((x) => x.id === id);
      return m ? view(m) : null;
    },

    async createMachine(data, authorId) {
      const id = state.machines.reduce((max, m) => Math.max(max, m.id), 0) + 1;
      const machine = {
        id, description: '', specs: [], ...data, authorId,
        createdAt: new Date().toISOString().slice(0, 10)
      };
      state.machines.push(machine);
      persist();
      return view(machine);
    },

    async updateMachine(id, data) {
      const i = state.machines.findIndex((x) => x.id === id);
      if (i === -1) return null;
      state.machines[i] = { ...state.machines[i], ...data };
      persist();
      return view(state.machines[i]);
    },

    async deleteMachine(id) {
      const before = state.machines.length;
      state.machines = state.machines.filter((x) => x.id !== id);
      persist();
      return state.machines.length < before;
    },

    async findUserByLogin(login) {
      return state.users.find((u) => u.login === login) ?? null;
    },

    async createSession(userId) {
      const token = randomBytes(32).toString('hex');
      sessions.set(token, userId);
      return token;
    },

    async getSessionUser(token) {
      const userId = sessions.get(token);
      const user = userId && state.users.find((u) => u.id === userId);
      return user ? publicUser(user) : null;
    },

    async deleteSession(token) {
      sessions.delete(token);
    },

    async close() {}
  };
}
