import { randomBytes } from 'node:crypto';
import pg from 'pg';

// Хранилище в PostgreSQL. Методы те же, что у jsonRepo, поэтому маршруты не знают, где лежат данные.
// Все значения передаются отдельно от текста запроса ($1, $2, ...): это защищает от SQL-инъекций.

const SESSION_DAYS = 7;

// Станок вместе с названием типа автора и списком характеристик одним запросом.
const MACHINE_SELECT = `
  SELECT m.id,
         m.title,
         m.type_code      AS "type",
         m.condition_code AS "condition",
         m.region,
         m.price,
         m.image,
         m.description,
         m.email,
         m.phone,
         m.author_id      AS "authorId",
         u.name           AS author,
         to_char(m.created_at, 'YYYY-MM-DD') AS "createdAt",
         COALESCE(
           (SELECT json_agg(json_build_object('name', s.name, 'value', s.value) ORDER BY s.sort_order)
              FROM machine_specs s WHERE s.machine_id = m.id),
           '[]'::json) AS specs
    FROM machines m
    JOIN users u ON u.id = m.author_id`;

export async function createPgRepo(databaseUrl) {
  const pool = new pg.Pool({ connectionString: databaseUrl });
  await pool.query('SELECT 1');          // сразу проверяем, что база доступна

  const one = async (text, params) => (await pool.query(text, params)).rows[0] ?? null;

  return {
    pool,

    async listMachines() {
      return (await pool.query(`${MACHINE_SELECT} ORDER BY m.id`)).rows;
    },

    async getMachine(id) {
      return one(`${MACHINE_SELECT} WHERE m.id = $1`, [id]);
    },

    async createMachine(data, authorId) {
      const created = await one(
        `INSERT INTO machines (title, type_code, condition_code, region, price, image, description, email, phone, author_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
         RETURNING id`,
        [data.title, data.type, data.condition, data.region, data.price, data.image, data.description ?? '', data.email, data.phone, authorId]
      );
      return this.getMachine(created.id);
    },

    async updateMachine(id, data) {
      const updated = await one(
        `UPDATE machines
            SET title = $1, type_code = $2, condition_code = $3, region = $4, price = $5,
                image = $6, email = $7, phone = $8, description = COALESCE($9, description)
          WHERE id = $10
      RETURNING id`,
        [data.title, data.type, data.condition, data.region, data.price, data.image, data.email, data.phone, data.description ?? null, id]
      );
      return updated ? this.getMachine(id) : null;
    },

    async deleteMachine(id) {
      const result = await pool.query('DELETE FROM machines WHERE id = $1 RETURNING id', [id]);
      return result.rows.length > 0;
    },

    async findUserByLogin(login) {
      return one('SELECT id, login, name, role, password_hash AS "passwordHash" FROM users WHERE login = $1', [login]);
    },

    async createSession(userId) {
      const token = randomBytes(32).toString('hex');
      await pool.query('INSERT INTO sessions (token, user_id) VALUES ($1, $2)', [token, userId]);
      return token;
    },

    async getSessionUser(token) {
      return one(
        `SELECT u.id, u.login, u.name, u.role
           FROM sessions s
           JOIN users u ON u.id = s.user_id
          WHERE s.token = $1
            AND s.created_at > now() - make_interval(days => $2)`,
        [token, SESSION_DAYS]
      );
    },

    async deleteSession(token) {
      await pool.query('DELETE FROM sessions WHERE token = $1', [token]);
    },

    async close() {
      await pool.end();
    }
  };
}
