// Стартовые данные: пользователи и станки. Используются при первом запуске сервера
// (лаба 7: файл data/db.json, лаба 8: наполнение базы командой npm run db:setup).
// Пароли здесь только для демонстрации, в хранилище они попадают уже хешированными.

export const USERS_SEED = [
  { login: 'admin', password: 'admin123', name: 'Надежда', role: 'admin' },
  { login: 'manager', password: 'manager123', name: 'Елена', role: 'manager' },
  { login: 'victoria', password: 'victoria123', name: 'Виктория', role: 'manager' }
];

export const MACHINES_SEED = [
  {
    "id": 1,
    "title": "Токарный станок 16К20",
    "type": "lathe",
    "condition": "used",
    "region": "Волгоградская область",
    "price": 1500000,
    "createdAt": "2026-07-12",
    "email": "info@temp.ru",
    "phone": "+7 (800) 555-35-35",
    "description": "Данный станок находится в Волгоградской области, в рабочем состоянии, отключен.",
    "specs": [
      {
        "name": "Масса, кг",
        "value": "2500"
      },
      {
        "name": "Диаметр обработки над станиной, мм",
        "value": "400"
      },
      {
        "name": "Диаметр обработки над суппортом, мм",
        "value": "220"
      }
    ],
    "image": "/uploads/16k20.jpeg",
    "authorLogin": "manager"
  },
  {
    "id": 2,
    "title": "1А64 РМЦ2800",
    "type": "lathe",
    "condition": "refurbished",
    "region": "Ленинградская обл.",
    "price": 5690000,
    "createdAt": "2026-08-03",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Тяжёлый токарно-винторезный станок после капитального ремонта. Документация в наличии.",
    "specs": [
      {
        "name": "Диаметр обработки над станиной, мм",
        "value": "640"
      },
      {
        "name": "Расстояние между центрами, мм",
        "value": "2800"
      }
    ],
    "image": null,
    "authorLogin": "manager"
  },
  {
    "id": 3,
    "title": "2С32",
    "type": "drilling",
    "condition": "used",
    "region": "Москва",
    "price": 774125,
    "createdAt": "2026-08-21",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Вертикально-сверлильный станок. Самовывоз со склада в Москве.",
    "specs": [
      {
        "name": "Наибольший диаметр сверления, мм",
        "value": "32"
      }
    ],
    "image": null,
    "authorLogin": "victoria"
  },
  {
    "id": 4,
    "title": "Резьбонакатной автомат 5А993",
    "type": "milling",
    "condition": "used",
    "region": "Воронежская область",
    "price": 2350000,
    "createdAt": "2026-11-15",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Автомат для накатки резьбы, состояние хорошее, возможен осмотр.",
    "specs": [],
    "image": null,
    "authorLogin": "manager"
  },
  {
    "id": 5,
    "title": "Горизонтально-фрезерный 6Р82Г",
    "type": "milling",
    "condition": "refurbished",
    "region": "Свердловская область",
    "price": 1890000,
    "createdAt": "2026-06-02",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Горизонтально-фрезерный станок после капитального ремонта, проверка на геометрическую точность.",
    "specs": [
      {
        "name": "Размер стола, мм",
        "value": "320 × 1250"
      }
    ],
    "image": null,
    "authorLogin": "victoria"
  },
  {
    "id": 6,
    "title": "Вертикально-фрезерный 6Р13",
    "type": "milling",
    "condition": "new",
    "region": "Москва",
    "price": 4250000,
    "createdAt": "2026-09-09",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Новый вертикально-фрезерный станок с гарантией производителя.",
    "specs": [
      {
        "name": "Размер стола, мм",
        "value": "400 × 1600"
      }
    ],
    "image": null,
    "authorLogin": "manager"
  },
  {
    "id": 7,
    "title": "Долбёжный 7А420",
    "type": "slotting",
    "condition": "used",
    "region": "Нижегородская область",
    "price": 960000,
    "createdAt": "2026-05-18",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Долбёжный станок для обработки пазов и шпоночных канавок.",
    "specs": [
      {
        "name": "Наибольший ход долбяка, мм",
        "value": "200"
      }
    ],
    "image": null,
    "authorLogin": "victoria"
  },
  {
    "id": 8,
    "title": "Токарный станок 1К62",
    "type": "lathe",
    "condition": "used",
    "region": "Краснодарский край",
    "price": 780000,
    "createdAt": "2026-04-27",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Токарно-винторезный станок, в рабочем состоянии.",
    "specs": [
      {
        "name": "Диаметр обработки над станиной, мм",
        "value": "400"
      },
      {
        "name": "Диаметр обработки над суппортом, мм",
        "value": "210"
      }
    ],
    "image": null,
    "authorLogin": "manager"
  },
  {
    "id": 9,
    "title": "Сверлильный 2Н125",
    "type": "drilling",
    "condition": "new",
    "region": "Санкт-Петербург",
    "price": 410000,
    "createdAt": "2026-09-30",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Новый вертикально-сверлильный станок для мастерской.",
    "specs": [
      {
        "name": "Наибольший диаметр сверления, мм",
        "value": "25"
      }
    ],
    "image": null,
    "authorLogin": "victoria"
  },
  {
    "id": 10,
    "title": "Токарный с ЧПУ CK6140",
    "type": "lathe",
    "condition": "new",
    "region": "Татарстан",
    "price": 3100000,
    "createdAt": "2026-10-05",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Токарный станок с ЧПУ, поставка со склада.",
    "specs": [],
    "image": null,
    "authorLogin": "manager"
  },
  {
    "id": 11,
    "title": "Фрезерный 6М12П",
    "type": "milling",
    "condition": "used",
    "region": "Ростовская область",
    "price": null,
    "createdAt": "2026-07-30",
    "email": "info@temp.ru",
    "phone": "+7 (928) 964-12-60",
    "description": "Вертикальный консольно-фрезерный станок. Цена договорная.",
    "specs": [],
    "image": null,
    "authorLogin": "victoria"
  }
];

// Справочники для базы данных (лаба 8)
export const TYPES_SEED = [
  ['milling', 'Фрезерные'],
  ['lathe', 'Токарные'],
  ['slotting', 'Долбежные'],
  ['drilling', 'Вертикально-сверлильный']
];

export const CONDITIONS_SEED = [
  ['used', 'Б/У'],
  ['refurbished', 'Капитальный ремонт'],
  ['new', 'Новый']
];
