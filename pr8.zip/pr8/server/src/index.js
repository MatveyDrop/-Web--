import { createApp } from './app.js';
import { config } from './config.js';
import { explainDbError } from './db/errors.js';
import { createPgRepo } from './repo/pgRepo.js';

let repo;
try {
  repo = await createPgRepo(config.databaseUrl);
} catch (err) {
  console.error(explainDbError(err, config.databaseUrl));
  process.exit(1);
}

const app = createApp({ repo, uploadsDir: config.uploadsDir, clientDist: config.clientDist });

app.listen(config.port, () => {
  console.log(`Сервер запущен: http://localhost:${config.port}`);
  console.log('База данных: PostgreSQL');
});
