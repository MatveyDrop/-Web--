// Небольшие общие middleware: журнал запросов, обёртка для async-обработчиков, обработка ошибок.

// Печатает в консоль «метод адрес код время» для каждого запроса, чтобы был виден путь запроса.
export function requestLogger(req, res, next) {
  const started = Date.now();
  res.on('finish', () => {
    console.log(`${req.method} ${req.originalUrl} -> ${res.statusCode} (${Date.now() - started} мс)`);
  });
  next();
}

// Ошибка из async-обработчика попадает в errorHandler через next(err).
export const wrap = (handler) => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

export function apiNotFound(req, res) {
  res.status(404).json({ error: 'Такого адреса нет' });
}

// Единое место, где ошибка превращается в ответ. Подробности наружу не отдаём.
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Некорректный JSON' });
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Слишком большой запрос' });
  if (err.status && err.status < 500) return res.status(err.status).json({ error: err.message });
  console.error(err);
  return res.status(500).json({ error: 'Внутренняя ошибка сервера' });
}
