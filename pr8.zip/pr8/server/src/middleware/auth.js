import { wrap } from './common.js';

// Читает заголовок «Authorization: Bearer <токен>» и кладёт пользователя в req.user (или null).
export const authenticate = (repo) => wrap(async (req, res, next) => {
  const header = req.headers.authorization ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  req.token = token;
  req.user = token ? await repo.getSessionUser(token) : null;
  next();
});

// Пропускает дальше только вошедших пользователей.
export function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Нужно войти' });
  return next();
}

// Администратор правит любые объявления, менеджер — только свои.
export const canModify = (user, machine) => user.role === 'admin' || machine.authorId === user.id;
