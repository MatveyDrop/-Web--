import fs from 'node:fs';
import express from 'express';
import { authenticate } from './middleware/auth.js';
import { apiNotFound, errorHandler, requestLogger } from './middleware/common.js';
import { authRouter } from './routes/auth.js';
import { machinesRouter } from './routes/machines.js';

// Собирает приложение из частей. Запрос проходит сверху вниз по цепочке:
// журнал -> разбор JSON -> определение пользователя -> нужный маршрут -> (ошибка) -> errorHandler.
export function createApp({ repo, uploadsDir, clientDist, log = true }) {
  const app = express();
  app.disable('x-powered-by');

  if (log) app.use(requestLogger);
  app.use(express.json({ limit: '3mb' }));

  app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

  app.use('/uploads', express.static(uploadsDir));
  app.use('/api', authenticate(repo));
  app.use('/api/auth', authRouter(repo));
  app.use('/api/machines', machinesRouter(repo, { uploadsDir }));
  app.use('/api', apiNotFound);

  if (clientDist && fs.existsSync(clientDist)) app.use(express.static(clientDist));

  app.use(errorHandler);
  return app;
}
