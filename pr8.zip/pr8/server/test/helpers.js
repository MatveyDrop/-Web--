import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../src/app.js';
import { createJsonRepo } from '../src/repo/jsonRepo.js';

// Поднимает приложение на свободном порту с временными файлами и возвращает функцию-клиент.
export async function startTestServer(createRepo = null) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'temp-test-'));
  const uploadsDir = path.join(dir, 'uploads');
  const repo = createRepo ? await createRepo() : await createJsonRepo(path.join(dir, 'db.json'));
  const app = createApp({ repo, uploadsDir, clientDist: null, log: false });
  const server = await new Promise((resolve) => { const s = app.listen(0, () => resolve(s)); });
  const base = `http://127.0.0.1:${server.address().port}`;

  async function api(method, url, { body, token } = {}) {
    const res = await fetch(base + url, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body)
    });
    const text = await res.text();
    let json = null;
    try { json = text ? JSON.parse(text) : null; } catch { /* не JSON */ }
    return { status: res.status, body: json, text };
  }

  async function login(name, password) {
    const r = await api('POST', '/api/auth/login', { body: { login: name, password } });
    return r.body?.token;
  }

  return {
    api, login, repo, uploadsDir, base,
    async close() { await new Promise((r) => server.close(r)); await repo.close(); fs.rmSync(dir, { recursive: true, force: true }); }
  };
}

export const goodMachine = {
  title: 'Тестовый станок', type: 'lathe', condition: 'used', region: 'Тула',
  price: 250000, email: 'test@temp.ru', phone: '+7 (900) 111-22-33', image: null
};
