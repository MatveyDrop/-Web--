import assert from 'node:assert/strict';
import { after, before, describe, test } from 'node:test';
import { setupDatabase } from '../src/db/setup.js';
import { createPgRepo } from '../src/repo/pgRepo.js';
import { apiSuite } from './api.test.js';

// Эти тесты работают с настоящей PostgreSQL и стирают в ней таблицы, поэтому нужна отдельная тестовая база.
// Запуск: TEST_DATABASE_URL=postgresql://localhost:5432/temp_test npm test
const url = process.env.TEST_DATABASE_URL;

if (!url) {
  test('тесты PostgreSQL пропущены: не задан TEST_DATABASE_URL', { skip: true }, () => {});
} else {
  apiSuite('API на PostgreSQL', async () => {
    await setupDatabase({ databaseUrl: url, reset: true });
    return createPgRepo(url);
  });

  describe('Ограничения и связи в базе', () => {
    let repo;
    before(async () => {
      await setupDatabase({ databaseUrl: url, reset: true });
      repo = await createPgRepo(url);
    });
    after(async () => { await repo.close(); });

    const insert = (over = {}) => {
      const v = { title: 'Станок', type: 'lathe', condition: 'used', region: 'Тула', price: 1000, email: 'a@b.ru', phone: '+7 (900) 111-22-33', ...over };
      return repo.pool.query(
        'INSERT INTO machines (title, type_code, condition_code, region, price, email, phone, author_id) VALUES ($1,$2,$3,$4,$5,$6,$7,1) RETURNING id',
        [v.title, v.type, v.condition, v.region, v.price, v.email, v.phone]
      );
    };

    test('заполнение: 3 пользователя, 11 станков, справочники и характеристики', async () => {
      const count = async (t) => (await repo.pool.query(`SELECT count(*)::int AS n FROM ${t}`)).rows[0].n;
      assert.equal(await count('users'), 3);
      assert.equal(await count('machines'), 11);
      assert.equal(await count('machine_types'), 4);
      assert.equal(await count('machine_conditions'), 3);
      assert.equal(await count('machine_specs'), 12);
    });

    test('повторное наполнение не дублирует данные', async () => {
      await setupDatabase({ databaseUrl: url });
      assert.equal((await repo.pool.query('SELECT count(*)::int AS n FROM machines')).rows[0].n, 11);
    });

    test('внешний ключ: неизвестный тип станка отклоняется', async () => {
      await assert.rejects(insert({ type: 'unknown' }), (e) => e.code === '23503');
    });

    test('проверка CHECK: цена должна быть больше нуля', async () => {
      await assert.rejects(insert({ price: 0 }), (e) => e.code === '23514');
      await assert.doesNotReject(insert({ price: null }));
    });

    test('логин уникален', async () => {
      await assert.rejects(
        repo.pool.query(`INSERT INTO users (login, password_hash, name, role) VALUES ('admin', 'x', 'Дубль', 'admin')`),
        (e) => e.code === '23505'
      );
    });

    test('удаление станка каскадно удаляет его характеристики', async () => {
      const specs = async () => (await repo.pool.query('SELECT count(*)::int AS n FROM machine_specs WHERE machine_id = 1')).rows[0].n;
      assert.equal(await specs(), 3);
      await repo.deleteMachine(1);
      assert.equal(await specs(), 0);
    });

    test('нельзя удалить пользователя, у которого есть объявления', async () => {
      await assert.rejects(repo.pool.query(`DELETE FROM users WHERE login = 'manager'`), (e) => e.code === '23503');
    });

    test('новый станок получает свободный номер (счётчик подвинут после наполнения)', async () => {
      const m = await repo.createMachine({ title: 'Новый станок', type: 'lathe', condition: 'new', region: 'Тула', price: 5000, image: null, email: 'a@b.ru', phone: '+7 (900) 111-22-33' }, 1);
      assert.ok(m.id > 11);
    });

    test('сессия старше 7 дней недействительна', async () => {
      const token = await repo.createSession(1);
      assert.equal((await repo.getSessionUser(token)).login, 'admin');
      await repo.pool.query(`UPDATE sessions SET created_at = now() - interval '8 days' WHERE token = $1`, [token]);
      assert.equal(await repo.getSessionUser(token), null);
    });
  });
}
