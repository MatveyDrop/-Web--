import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { after, before, describe, test } from 'node:test';
import { goodMachine, startTestServer } from './helpers.js';

// Тесты запускаются с любым хранилищем. По умолчанию — JSON-файл; в лабе 8 те же тесты прогоняются на PostgreSQL.
export function apiSuite(name, createRepo) {
  describe(name, () => {
    let s;
    before(async () => { s = await startTestServer(createRepo); });
    after(async () => { await s.close(); });

    test('health', async () => {
      const r = await s.api('GET', '/api/health');
      assert.equal(r.status, 200);
      assert.equal(r.body.status, 'ok');
    });

    test('список станков публичный и содержит 11 записей с автором', async () => {
      const r = await s.api('GET', '/api/machines');
      assert.equal(r.status, 200);
      assert.equal(r.body.length, 11);
      const first = r.body[0];
      assert.equal(first.title, 'Токарный станок 16К20');
      assert.equal(first.author, 'Елена');
      assert.equal(first.price, 1500000);
      assert.equal(first.createdAt, '2026-07-12');
      assert.equal(first.specs.length, 3);
      assert.equal(first.image, '/uploads/16k20.jpeg');
      assert.equal(r.body.find((m) => m.id === 11).price, null);
    });

    test('один станок и ошибки адреса', async () => {
      assert.equal((await s.api('GET', '/api/machines/3')).body.title, '2С32');
      assert.equal((await s.api('GET', '/api/machines/999')).status, 404);
      assert.equal((await s.api('GET', '/api/machines/abc')).status, 404);
      assert.equal((await s.api('GET', '/api/nothing')).status, 404);
    });

    test('вход: неверный пароль, пустое тело, успех, /me, выход', async () => {
      assert.equal((await s.api('POST', '/api/auth/login', { body: { login: 'admin', password: 'wrong' } })).status, 401);
      assert.equal((await s.api('POST', '/api/auth/login', { body: { login: 'nobody', password: 'admin123' } })).status, 401);
      assert.equal((await s.api('POST', '/api/auth/login', { body: {} })).status, 400);
      const ok = await s.api('POST', '/api/auth/login', { body: { login: 'admin', password: 'admin123' } });
      assert.equal(ok.status, 200);
      assert.equal(ok.body.user.role, 'admin');
      assert.equal(ok.body.user.passwordHash, undefined);
      assert.equal((await s.api('GET', '/api/auth/me', { token: ok.body.token })).body.user.name, 'Надежда');
      assert.equal((await s.api('POST', '/api/auth/logout', { token: ok.body.token })).status, 204);
      assert.equal((await s.api('GET', '/api/auth/me', { token: ok.body.token })).status, 401);
    });

    test('без входа менять данные нельзя', async () => {
      assert.equal((await s.api('POST', '/api/machines', { body: goodMachine })).status, 401);
      assert.equal((await s.api('PUT', '/api/machines/1', { body: goodMachine })).status, 401);
      assert.equal((await s.api('DELETE', '/api/machines/1')).status, 401);
      assert.equal((await s.api('POST', '/api/machines', { body: goodMachine, token: 'invalid-token' })).status, 401);
    });

    test('менеджер: создаёт, правит своё, не трогает чужое; автор берётся из сессии', async () => {
      const token = await s.login('manager', 'manager123');
      const created = await s.api('POST', '/api/machines', { token, body: { ...goodMachine, author: 'Подделка', authorId: 1 } });
      assert.equal(created.status, 201);
      assert.equal(created.body.author, 'Елена');
      assert.equal(created.body.createdAt, new Date().toISOString().slice(0, 10));
      const id = created.body.id;

      const upd = await s.api('PUT', `/api/machines/${id}`, { token, body: { ...goodMachine, title: 'Новое название', price: null } });
      assert.equal(upd.status, 200);
      assert.equal(upd.body.title, 'Новое название');
      assert.equal(upd.body.price, null);
      assert.equal(upd.body.author, 'Елена');

      // станок 3 принадлежит Виктории
      assert.equal((await s.api('PUT', '/api/machines/3', { token, body: goodMachine })).status, 403);
      assert.equal((await s.api('DELETE', '/api/machines/3', { token })).status, 403);

      assert.equal((await s.api('DELETE', `/api/machines/${id}`, { token })).status, 204);
      assert.equal((await s.api('GET', `/api/machines/${id}`)).status, 404);
    });

    test('администратор правит и удаляет чужое', async () => {
      const token = await s.login('admin', 'admin123');
      assert.equal((await s.api('PUT', '/api/machines/3', { token, body: { ...goodMachine, title: 'Правка админа' } })).status, 200);
      assert.equal((await s.api('DELETE', '/api/machines/3', { token })).status, 204);
      assert.equal((await s.api('DELETE', '/api/machines/3', { token })).status, 404);
    });

    test('правка не затирает характеристики', async () => {
      const token = await s.login('admin', 'admin123');
      await s.api('PUT', '/api/machines/1', { token, body: { ...goodMachine, image: '/uploads/16k20.jpeg' } });
      const m = (await s.api('GET', '/api/machines/1')).body;
      assert.equal(m.specs.length, 3);
      assert.equal(m.image, '/uploads/16k20.jpeg');
    });

    test('неверные данные: 400 с описанием полей', async () => {
      const token = await s.login('manager', 'manager123');
      const r = await s.api('POST', '/api/machines', { token, body: { title: 'a', price: -1 } });
      assert.equal(r.status, 400);
      assert.ok(r.body.fields.title && r.body.fields.price && r.body.fields.phone);
    });

    test('сломанный JSON: 400', async () => {
      const res = await fetch(`${s.base}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{oops' });
      assert.equal(res.status, 400);
    });

    test('фото: data URL сохраняется файлом и раздаётся; не-изображение отклоняется', async () => {
      const token = await s.login('manager', 'manager123');
      const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
      const ok = await s.api('POST', '/api/machines', { token, body: { ...goodMachine, image: `data:image/png;base64,${png.toString('base64')}` } });
      assert.equal(ok.status, 201);
      assert.match(ok.body.image, /^\/uploads\/[\w-]+\.png$/);
      assert.ok(fs.existsSync(path.join(s.uploadsDir, path.basename(ok.body.image))));
      const file = await fetch(s.base + ok.body.image);
      assert.equal(file.status, 200);
      assert.deepEqual(Buffer.from(await file.arrayBuffer()), png);

      const fake = await s.api('POST', '/api/machines', { token, body: { ...goodMachine, image: `data:image/png;base64,${Buffer.from('это текст').toString('base64')}` } });
      assert.equal(fake.status, 400);
    });
  });
}

apiSuite('API на JSON-хранилище', null);
