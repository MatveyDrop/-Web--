import assert from 'node:assert/strict';
import test from 'node:test';
import { hashPassword, verifyPassword } from '../src/auth/passwords.js';
import { parseId, validateLogin, validateMachine } from '../src/validation.js';
import { goodMachine } from './helpers.js';

test('корректный станок проходит проверку', () => {
  const r = validateMachine(goodMachine);
  assert.equal(r.valid, true);
  assert.equal(r.value.title, 'Тестовый станок');
});

test('цена договорная: price = null допустимо', () => {
  assert.equal(validateMachine({ ...goodMachine, price: null }).valid, true);
});

test('плохие значения дают ошибки по полям', () => {
  const r = validateMachine({ title: 'ab', type: 'x', condition: 'y', region: '', price: -5, email: 'bad@mail', phone: '123', image: 'http://evil' });
  assert.deepEqual(Object.keys(r.errors).sort(), ['condition', 'email', 'image', 'phone', 'price', 'region', 'title', 'type']);
});

test('цена: дробная и строка отклоняются', () => {
  assert.ok(validateMachine({ ...goodMachine, price: 10.5 }).errors.price);
  assert.ok(validateMachine({ ...goodMachine, price: '100' }).errors.price);
});

test('image: путь к загрузке и data URL допустимы, чужой адрес нет', () => {
  assert.equal(validateMachine({ ...goodMachine, image: '/uploads/a-1.jpg' }).valid, true);
  assert.equal(validateMachine({ ...goodMachine, image: 'data:image/png;base64,AAAA' }).valid, true);
  assert.ok(validateMachine({ ...goodMachine, image: '/uploads/../secret' }).errors.image);
});

test('тело не объект не падает', () => {
  assert.equal(validateMachine(null).valid, false);
  assert.equal(validateLogin(undefined), null);
});

test('parseId принимает только положительные целые', () => {
  assert.equal(parseId('5'), 5);
  assert.equal(parseId('0'), null);
  assert.equal(parseId('abc'), null);
  assert.equal(parseId('1.5'), null);
});

test('пароли: хеш проверяется, соль разная', async () => {
  const a = await hashPassword('secret123');
  const b = await hashPassword('secret123');
  assert.notEqual(a, b);
  assert.equal(await verifyPassword('secret123', a), true);
  assert.equal(await verifyPassword('wrong', a), false);
  assert.equal(await verifyPassword('x', 'мусор'), false);
});
