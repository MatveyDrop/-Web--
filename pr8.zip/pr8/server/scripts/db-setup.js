import { config } from '../src/config.js';
import { setupDatabase } from '../src/db/setup.js';
import { explainDbError } from '../src/db/errors.js';

const reset = process.argv.includes('--reset');

try {
  await setupDatabase({ databaseUrl: config.databaseUrl, reset, log: (line) => console.log(line) });
  console.log('Готово.');
} catch (err) {
  console.error(explainDbError(err, config.databaseUrl));
  process.exit(1);
}
