import { Router, Routes } from './router';
import { AuthProvider } from './context/AuthContext';
import { MachinesProvider } from './context/MachinesContext';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import About from './pages/About';
import Catalog from './pages/Catalog';
import MachinePage from './pages/MachinePage';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import MachineEditor from './pages/MachineEditor';
import NotFound from './pages/NotFound';

const routes = [
  { path: '/', element: <Home /> },
  { path: '/about', element: <About /> },
  { path: '/catalog', element: <Catalog /> },
  { path: '/login', element: <Login /> },
  { path: '/admin', element: <ProtectedRoute role="admin"><Dashboard role="admin" /></ProtectedRoute> },
  { path: '/manager', element: <ProtectedRoute role="manager"><Dashboard role="manager" /></ProtectedRoute> },
  { path: '/machines/new', element: <ProtectedRoute><MachineEditor mode="add" /></ProtectedRoute> },
  { path: '/machines/:id', element: <MachinePage /> },
  { path: '/machines/:id/edit', element: <ProtectedRoute><MachineEditor mode="edit" /></ProtectedRoute> }
];

export default function App() {
  return (
    <AuthProvider>
      <MachinesProvider>
        <Router>
          <Routes routes={routes} fallback={<NotFound />} />
        </Router>
      </MachinesProvider>
    </AuthProvider>
  );
}
