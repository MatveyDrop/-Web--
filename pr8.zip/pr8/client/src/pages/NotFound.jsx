import Layout from '../components/Layout';
import { Link } from '../router';

export default function NotFound() {
  return (
    <Layout title="Страница не найдена">
      <p className="empty-state">Такой страницы нет. <Link to="/">На главную</Link></p>
    </Layout>
  );
}
