import { useEffect, useMemo, useState } from 'react';
import Layout from '../components/Layout';
import Filters from '../components/Filters';
import MachineCard from '../components/MachineCard';
import Pagination from '../components/Pagination';
import { useMachines } from '../context/MachinesContext';
import { useSearchParams } from '../router';
import { typeLabel } from '../utils/format';

const PAGE_SIZE = 6;

export default function Catalog() {
  const { machines, status } = useMachines();
  const [params, setParams] = useSearchParams();

  // Источник правды для фильтров — адресная строка: ссылку на каталог с фильтрами можно отправить другому человеку.
  const q = params.get('q') ?? '';
  const type = params.get('type') ?? '';
  const condition = params.get('condition') ?? '';
  const requestedPage = Math.max(1, parseInt(params.get('page'), 10) || 1);

  // Текст в поле меняется сразу, а в адрес и фильтр попадает с задержкой.
  const [text, setText] = useState(q);
  useEffect(() => { setText(q); }, [q]);

  const update = (patch) => {
    const next = { q, type, condition, page: String(requestedPage), ...patch };
    const clean = {};
    Object.entries(next).forEach(([k, v]) => { if (v && !(k === 'page' && v === '1')) clean[k] = v; });
    setParams(clean);
  };

  useEffect(() => {
    if (text === q) return undefined;
    const timer = setTimeout(() => update({ q: text, page: '1' }), 250);
    return () => clearTimeout(timer);
  }, [text]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return machines.filter((m) => {
      if (type && m.type !== type) return false;
      if (condition && m.condition !== condition) return false;
      if (needle && !`${m.title} ${m.region} ${typeLabel(m.type)}`.toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [machines, q, type, condition]);

  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const page = Math.min(requestedPage, pages);
  const visible = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const hrefFor = (n) => {
    const p = new URLSearchParams();
    if (q) p.set('q', q);
    if (type) p.set('type', type);
    if (condition) p.set('condition', condition);
    if (n > 1) p.set('page', n);
    const qs = p.toString();
    return `/catalog${qs ? `?${qs}` : ''}`;
  };

  return (
    <Layout title="Каталог">
      <h1>Каталог промышленного оборудования</h1>

      <Filters
        text={text}
        type={type}
        condition={condition}
        onText={setText}
        onType={(value) => update({ type: value, page: '1' })}
        onCondition={(value) => update({ condition: value, page: '1' })}
        onApply={() => update({ q: text, page: '1' })}
        onReset={() => { setText(''); setParams({}); }}
      />

      {status === 'loading' && <p className="result-count">Загрузка каталога…</p>}
      {status === 'error' && <p className="form-error">Не удалось загрузить каталог. Обновите страницу.</p>}

      {status === 'ready' && (
        <>
          <p className="result-count" aria-live="polite">Найдено станков: {filtered.length}</p>
          <div className="machines-grid">
            {visible.length === 0
              ? <p className="empty-state">По вашему запросу станков не найдено. Измените условия поиска.</p>
              : visible.map((m) => <MachineCard key={m.id} machine={m} />)}
          </div>
          <Pagination page={page} pages={pages} hrefFor={hrefFor} />
        </>
      )}
    </Layout>
  );
}
