import { Fragment, useState } from 'react';
import Layout from '../components/Layout';
import SafeImage from '../components/SafeImage';
import TextField from '../components/TextField';
import { Link, useNavigate, useParams } from '../router';
import { TYPES, CONDITIONS } from '../data/seed';
import { useAuth } from '../context/AuthContext';
import { useMachines } from '../context/MachinesContext';
import { asset, typeLabel } from '../utils/format';
import { shrinkImage } from '../utils/image';
import { check, findType, machineRules, validateForm } from '../utils/validation';

const EMPTY = {
  title: '', type: '', condition: 'used', region: '', price: '',
  negotiable: false, email: '', phone: '', image: ''
};
const CONDITION_ORDER = ['used', 'new', 'refurbished'];   // порядок кнопок как в макете
const ORDER = ['title', 'type', 'region', 'price', 'email', 'phone'];   // порядок полей для фокуса на ошибке

function toValues(m) {
  return {
    title: m.title, type: typeLabel(m.type), condition: m.condition, region: m.region,
    price: m.price === null ? '' : String(m.price), negotiable: m.price === null,
    email: m.email, phone: m.phone, image: m.image ?? ''
  };
}

// Форма: все значения и ошибки хранятся в ней самой, наружу уходит только готовый объект станка.
function MachineForm({ mode, initial, onSave }) {
  const [values, setValues] = useState(initial);
  const [errors, setErrors] = useState({});
  const [photoError, setPhotoError] = useState('');
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState('');

  const skip = (field, v = values) => field === 'price' && v.negotiable;

  const setField = (field, value) => {
    setValues((v) => ({ ...v, [field]: value }));
    if (errors[field] && !check(value, machineRules[field])) setErrors((er) => ({ ...er, [field]: '' }));
  };
  const bind = (field) => ({
    id: `f-${field}`,
    value: values[field],
    error: errors[field],
    onChange: (e) => setField(field, e.target.value),
    onBlur: () => {
      if (values[field] !== '' && !skip(field)) {
        setErrors((er) => ({ ...er, [field]: check(values[field], machineRules[field]) }));
      }
    }
  });

  const toggleNegotiable = (e) => {
    const on = e.target.checked;
    setValues((v) => ({ ...v, negotiable: on, price: on ? '' : v.price }));
    if (on) setErrors((er) => ({ ...er, price: '' }));
  };

  const onPhoto = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { setPhotoError('Выберите файл изображения (JPG, PNG, WEBP)'); e.target.value = ''; return; }
    if (file.size > 5 * 1024 * 1024) { setPhotoError('Размер файла не должен превышать 5 МБ'); e.target.value = ''; return; }
    try {
      const data = await shrinkImage(file);
      setValues((v) => ({ ...v, image: data }));
      setPhotoError('');
    } catch {
      setPhotoError('Не удалось прочитать изображение');
    }
  };

  const submit = async (e) => {
    e.preventDefault();
    const found = validateForm(values, machineRules, (f) => skip(f));
    setErrors(found);
    const first = ORDER.find((f) => found[f]);
    if (first) { document.getElementById(`f-${first}`)?.focus(); return; }

    setSaving(true);
    setServerError('');
    try {
      await onSave({
        title: values.title.trim(),
        type: findType(values.type).value,
        condition: values.condition,
        region: values.region.trim(),
        price: values.negotiable ? null : Number(values.price),
        image: values.image || null,
        email: values.email.trim(),
        phone: values.phone.trim()
      });
    } catch (err) {
      // сервер проверил данные сам и вернул ошибки по полям
      if (err.fields) setErrors(err.fields);
      setServerError(err.message);
      setSaving(false);
    }
  };

  return (
    <form className="add-machine-form" onSubmit={submit} noValidate>
      <div>
        <label className="photo-upload" htmlFor="photo">
          {values.image ? (
            <>
              <SafeImage src={values.image} alt="Фото станка" className="photo-current" />
              <p className="photo-caption">Изменить фото станка</p>
            </>
          ) : (
            <>
              <img src={asset('icon-cloud.png')} alt="" className="cloud-icon-img" />
              <p>Добавить фото станка</p>
            </>
          )}
          <input type="file" accept="image/*" id="photo" hidden onChange={onPhoto} />
        </label>
        {photoError && <div className="invalid-feedback is-shown" role="alert">{photoError}</div>}

        <div className="contact-block">
          <h3>Контактные данные</h3>
          <TextField type="email" aria-label="Email для связи" placeholder="name_surname@example.com" {...bind('email')} />
          <TextField type="tel" aria-label="Телефон для связи" placeholder="+7 (992) 433-12-12" {...bind('phone')} />
        </div>
      </div>

      <div className="form-fields">
        <TextField type="text" aria-label="Название станка" placeholder="Введите название станка" {...bind('title')} />

        <div className="segmented-control" role="radiogroup" aria-label="Состояние станка">
          {CONDITION_ORDER.map((v) => CONDITIONS.find((c) => c.value === v)).map((c) => (
            <Fragment key={c.value}>
              <input type="radio" name="condition" id={c.value} checked={values.condition === c.value}
                onChange={() => setValues((v) => ({ ...v, condition: c.value }))} />
              <label htmlFor={c.value}>{c.label}</label>
            </Fragment>
          ))}
        </div>

        <TextField type="text" list="type-list" autoComplete="off" aria-label="Тип станка"
          placeholder="Укажите тип станка" {...bind('type')} />
        <datalist id="type-list">
          {TYPES.map((t) => <option key={t.value} value={t.label} />)}
        </datalist>

        <TextField type="text" aria-label="Местоположение станка"
          placeholder="Укажите местоположение станка (регион, округ)" {...bind('region')} />
        <TextField type="number" min="1" step="1" aria-label="Цена станка" placeholder="Укажите цену станка"
          disabled={values.negotiable} {...bind('price')} />

        <div className="checkbox-group">
          <input type="checkbox" id="negotiable" checked={values.negotiable} onChange={toggleNegotiable} />
          <label htmlFor="negotiable">Цена договорная</label>
        </div>
      </div>

      {serverError && <p className="form-error" role="alert" style={{ gridColumn: '1 / -1' }}>{serverError}</p>}
      <button type="submit" className="btn btn-primary submit-btn" disabled={saving}>
        {mode === 'add' ? 'Создать объявление' : 'Сохранить изменения'}
      </button>
    </form>
  );
}

export default function MachineEditor({ mode }) {
  const { user } = useAuth();
  const { id } = useParams();
  const { status, getById, addMachine, updateMachine } = useMachines();
  const navigate = useNavigate();

  const title = mode === 'add' ? 'Добавить станок' : 'Редактировать станок';
  const machine = mode === 'edit' ? getById(id) : null;
  const denied = machine && user.role !== 'admin' && machine.authorId !== user.id;

  if (mode === 'edit' && status === 'loading') {
    return <Layout title={title} mainClass="add-machine-page"><p className="empty-state">Загрузка…</p></Layout>;
  }
  if (mode === 'edit' && (!machine || denied)) {
    return (
      <Layout title={title} mainClass="add-machine-page">
        <p className="empty-state">Объявление не найдено или недоступно. <Link to={user.page}>Вернуться в кабинет</Link></p>
      </Layout>
    );
  }

  const save = async (data) => {
    if (mode === 'add') {
      await addMachine(data);       // автора и дату создания проставляет сервер
    } else {
      await updateMachine(machine.id, data);
    }
    navigate(user.page);
  };

  return (
    <Layout title={title} mainClass="add-machine-page">
      <Link to={user.page} className="back-link">←</Link>
      <h1>{title}</h1>
      <MachineForm mode={mode} initial={machine ? toValues(machine) : EMPTY} onSave={save} />
    </Layout>
  );
}
