import { useState } from 'react';
import Layout from '../components/Layout';
import TextField from '../components/TextField';
import { Navigate, useNavigate } from '../router';
import { useAuth } from '../context/AuthContext';
import { asset } from '../utils/format';
import { check, loginRules, validateForm } from '../utils/validation';

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState({ login: '', password: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [pending, setPending] = useState(false);

  if (user) return <Navigate to={user.page} />;

  const change = (field) => (e) => {
    const value = e.target.value;
    setValues((v) => ({ ...v, [field]: value }));
    if (errors[field] && !check(value, loginRules[field])) setErrors((er) => ({ ...er, [field]: '' }));
  };

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    const found = validateForm(values, loginRules);
    setErrors(found);
    if (Object.keys(found).length) return;

    setPending(true);
    try {
      const signed = await login(values.login.trim(), values.password);
      navigate(signed.page);
    } catch (err) {
      setFormError(err.message);
      setValues((v) => ({ ...v, password: '' }));
      setPending(false);
    }
  };

  return (
    <Layout title="Вход" mainClass="login-page">
      <div className="login-logo">
        <img src={asset('logoTemp.jpg')} alt="Логотип ТЕМП" />
      </div>
      <h2>Вход для сотрудников</h2>
      <form className="login-form" onSubmit={submit} noValidate>
        <div className="form-group">
          <label htmlFor="login">Логин</label>
          <TextField id="login" name="login" type="text" placeholder="Введите логин" autoComplete="username"
            value={values.login} onChange={change('login')} error={errors.login} />
        </div>
        <div className="form-group">
          <label htmlFor="password">Пароль</label>
          <TextField id="password" name="password" type="password" placeholder="Введите пароль" autoComplete="current-password"
            value={values.password} onChange={change('password')} error={errors.password} />
        </div>
        {formError && <p id="login-error" className="form-error" role="alert">{formError}</p>}
        <button type="submit" className="btn btn-primary" disabled={pending}>Войти</button>
        <p className="login-hint">Демо-доступ: admin / admin123 или manager / manager123</p>
      </form>
    </Layout>
  );
}
