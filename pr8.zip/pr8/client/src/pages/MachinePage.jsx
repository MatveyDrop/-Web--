import { useState } from 'react';
import Layout from '../components/Layout';
import SafeImage from '../components/SafeImage';
import { Link, useParams } from '../router';
import { useMachines } from '../context/MachinesContext';
import { asset, conditionLabel, formatPrice, typeLabel } from '../utils/format';

export default function MachinePage() {
  const { id } = useParams();
  const { status, getById } = useMachines();
  const [tab, setTab] = useState('description');        // активная вкладка — локальное состояние страницы
  const machine = getById(id);

  if (status === 'loading') {
    return <Layout title="Станок"><p className="empty-state">Загрузка…</p></Layout>;
  }
  if (!machine) {
    return (
      <Layout title="Станок не найден">
        <Link to="/catalog" className="back-link">←</Link>
        <p className="empty-state">Станок не найден. <Link to="/catalog">Вернуться в каталог</Link></p>
      </Layout>
    );
  }

  const specs = [{ name: 'Тип станка', value: typeLabel(machine.type) }, ...(machine.specs ?? [])];

  return (
    <Layout title={machine.title}>
      <Link to="/catalog" className="back-link">←</Link>

      <div className="machine-info">
        <SafeImage src={machine.image} alt={machine.title} />
        <div className="machine-details">
          <h1>{machine.title}</h1>
          <p><strong>Состояние:</strong> {conditionLabel(machine.condition)}</p>
          <p><strong>Местонахождение:</strong> {machine.region}</p>
          <p className="price">{formatPrice(machine.price)}</p>
          <div className="machine-actions">
            <a href={`tel:${machine.phone.replace(/[^\d+]/g, '')}`} className="btn btn-outline">
              <img src={asset('icon-phone.png')} alt="" className="icon-sm icon-phone" /> Позвонить
            </a>
            <a href={`mailto:${machine.email}?subject=${encodeURIComponent(machine.title)}`} className="btn btn-primary">
              <img src={asset('icon-mail-white.png')} alt="" className="icon-sm" /> Написать
            </a>
          </div>
        </div>
      </div>

      <div className="tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === 'description'}
          className={tab === 'description' ? 'active' : undefined} onClick={() => setTab('description')}>
          Описание
        </button>
        <button type="button" role="tab" aria-selected={tab === 'characteristics'}
          className={tab === 'characteristics' ? 'active' : undefined} onClick={() => setTab('characteristics')}>
          Характеристики
        </button>
      </div>

      {tab === 'description' ? (
        <div className="tab-content">
          <h3>Описание</h3>
          <p>{machine.description || 'Описание не указано.'}</p>
        </div>
      ) : (
        <div className="tab-content">
          <h3>Характеристики</h3>
          <table className="specs-table">
            <tbody>
              {specs.map((s) => <tr key={s.name}><th>{s.name}</th><td>{s.value}</td></tr>)}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
