import Layout from '../components/Layout';
import { Link } from '../router';
import { asset } from '../utils/format';

const FEATURES = [
  { icon: 'icon-gear.png', alt: 'Ассортимент', title: 'Широкий ассортимент', text: 'Фрезерные, токарные, долбёжные, сверлильные' },
  { icon: 'icon-shield.png', alt: 'Гарантия', title: 'Гарантия качества', text: 'На все станки даётся гарантия на ремонт' },
  { icon: 'icon-truck.png', alt: 'Доставка', title: 'Быстрая доставка', text: 'Организуем доставку по России за кратчайшие сроки' }
];

export default function Home() {
  return (
    <Layout>
      <section className="hero">
        <h1>Промышленные станки</h1>
        <p>Новые, Б/У и после капремонта с гарантией качества</p>
        <Link to="/catalog" className="btn btn-white">Посмотреть каталог</Link>
      </section>

      <section className="features">
        <h2>Почему выбирают нас?</h2>
        <p>Более 10 лет опыта на рынке промышленного оборудования</p>
        <div className="features-grid">
          {FEATURES.map((f) => (
            <div className="feature-item" key={f.title}>
              <img src={asset(f.icon)} alt={f.alt} className="feature-icon-img" />
              <h3>{f.title}</h3>
              <p>{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="cta">
        <h2>Хотите найти станок?</h2>
        <p>Просмотрите каталог или свяжитесь с нами</p>
        <div className="cta-buttons">
          <Link to="/catalog" className="btn btn-white">Посмотреть каталог</Link>
          <a href="mailto:info@temp.ru" className="btn btn-outline-white">
            <img src={asset('icon-mail-white.png')} alt="" className="icon-sm" /> Связаться с нами
          </a>
        </div>
      </section>
    </Layout>
  );
}
