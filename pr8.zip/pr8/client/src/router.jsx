// Минимальный маршрутизатор на хэше адреса (#/catalog?type=lathe).
// Работает без настройки сервера и при открытии сайта как статических файлов.
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const RouterContext = createContext(null);
const ParamsContext = createContext({});

function readHash() {
  const raw = window.location.hash.replace(/^#/, '') || '/';
  const i = raw.indexOf('?');
  return {
    path: (i === -1 ? raw : raw.slice(0, i)) || '/',
    search: i === -1 ? '' : raw.slice(i + 1)
  };
}

export function Router({ children }) {
  const [location, setLocation] = useState(readHash);

  useEffect(() => {
    const onChange = () => setLocation(readHash());
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  const navigate = useCallback((to, { replace = false } = {}) => {
    if (replace) {
      // replaceState не вызывает hashchange, поэтому обновляем состояние вручную
      window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}#${to}`);
      setLocation(readHash());
    } else {
      window.location.hash = to;
    }
  }, []);

  const value = useMemo(() => ({ location, navigate }), [location, navigate]);
  return <RouterContext.Provider value={value}>{children}</RouterContext.Provider>;
}

function matchPath(pattern, path) {
  const a = pattern.split('/').filter(Boolean);
  const b = path.split('/').filter(Boolean);
  if (a.length !== b.length) return null;
  const params = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

// routes: [{ path: '/machines/:id', element: <MachinePage /> }]
export function Routes({ routes, fallback }) {
  const { location } = useContext(RouterContext);

  useEffect(() => { window.scrollTo(0, 0); }, [location.path]);

  for (const route of routes) {
    const params = matchPath(route.path, location.path);
    if (params) {
      return (
        <ParamsContext.Provider value={params} key={location.path}>
          {route.element}
        </ParamsContext.Provider>
      );
    }
  }
  return fallback;
}

export function Link({ to, children, ...rest }) {
  return <a href={`#${to}`} {...rest}>{children}</a>;
}

export function Navigate({ to }) {
  const { navigate } = useContext(RouterContext);
  useEffect(() => { navigate(to, { replace: true }); }, [navigate, to]);
  return null;
}

export const useLocation = () => useContext(RouterContext).location;
export const useNavigate = () => useContext(RouterContext).navigate;
export const useParams = () => useContext(ParamsContext);

export function useSearchParams() {
  const { location, navigate } = useContext(RouterContext);
  const params = useMemo(() => new URLSearchParams(location.search), [location.search]);
  const setParams = useCallback((next) => {
    const qs = new URLSearchParams(next).toString();
    navigate(`${location.path}${qs ? `?${qs}` : ''}`, { replace: true });
  }, [location.path, navigate]);
  return [params, setParams];
}
