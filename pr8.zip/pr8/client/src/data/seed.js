// Справочники для выпадающих списков и подписей. Сами станки и пользователи теперь приходят с сервера.

export const TYPES = [
  { value: 'milling', label: 'Фрезерные' },
  { value: 'lathe', label: 'Токарные' },
  { value: 'slotting', label: 'Долбежные' },
  { value: 'drilling', label: 'Вертикально-сверлильный' }
];

export const CONDITIONS = [
  { value: 'used', label: 'Б/У' },
  { value: 'refurbished', label: 'Капитальный ремонт' },
  { value: 'new', label: 'Новый' }
];
