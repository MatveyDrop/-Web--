import { useEffect } from 'react';
import Header from './Header';
import Footer from './Footer';

// Общая рамка страницы: шапка, содержимое и подвал. Класс <main> и заголовок вкладки задаёт страница.
export default function Layout({ title, mainClass, children }) {
  useEffect(() => {
    document.title = title ? `${title} — ТЕМП` : 'ТЕМП — промышленные станки';
  }, [title]);

  return (
    <>
      <Header />
      <main className={mainClass}>{children}</main>
      <Footer />
    </>
  );
}
