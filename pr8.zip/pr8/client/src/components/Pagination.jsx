import { Link } from '../router';

export default function Pagination({ page, pages, hrefFor }) {
  if (pages <= 1) return null;
  const numbers = Array.from({ length: pages }, (_, i) => i + 1);
  return (
    <nav className="pagination" aria-label="Пагинация">
      {numbers.map((n) => (
        <Link
          key={n}
          to={hrefFor(n)}
          className={n === page ? 'active' : undefined}
          aria-current={n === page ? 'page' : undefined}
          aria-label={`Страница ${n}`}
        >
          {n}
        </Link>
      ))}
    </nav>
  );
}
