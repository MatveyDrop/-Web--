import { asset } from '../utils/format';

export default function Footer() {
  return (
    <footer>
      <div className="container">
        <div>
          <p>
            <img src={asset('icon-mail-white.png')} alt="" className="icon-sm" />
            <a href="mailto:info@temp.ru">info@temp.ru</a>
          </p>
          <p>
            <img src={asset('icon-phone.png')} alt="" className="icon-sm icon-phone" />
            <a href="tel:+79289641260">+7 (928) 964-12-60</a>
          </p>
          <p>ИНН: [номер]</p>
        </div>
        <div className="copyright">
          <p>&copy; 2016-2026. ООО "ТЕМП"</p>
        </div>
      </div>
    </footer>
  );
}
