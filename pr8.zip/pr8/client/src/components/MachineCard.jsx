import { Link } from '../router';
import SafeImage from './SafeImage';
import { asset, formatPrice, typeLabel } from '../utils/format';

export default function MachineCard({ machine }) {
  return (
    <article className="machine-card">
      <SafeImage src={machine.image} alt={machine.title} className="card-img" loading="lazy" />
      <div className="card-header">
        <h3>{machine.title}</h3>
        <span className="card-category">
          <img src={asset('icon-gear.png')} alt="" className="icon-sm" /> {typeLabel(machine.type)}
        </span>
      </div>
      <div className="card-region">
        <img src={asset('icon-pin.png')} alt="" className="icon-sm" /> {machine.region}
      </div>
      <div className="card-footer">
        <span className="price">{formatPrice(machine.price)}</span>
        <Link to={`/machines/${machine.id}`} className="btn btn-primary">Подробнее</Link>
      </div>
    </article>
  );
}
