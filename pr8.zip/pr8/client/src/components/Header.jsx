import { Link, useLocation } from '../router';
import { useAuth } from '../context/AuthContext';
import { asset } from '../utils/format';

const isCabinetPath = (path) =>
  ['/admin', '/manager', '/machines/new'].includes(path) || /^\/machines\/\d+\/edit$/.test(path);

export default function Header() {
  const { path } = useLocation();
  const { user, logout } = useAuth();
  const cls = (active) => (active ? 'active' : undefined);

  return (
    <header>
      <div className="header-logo">
        <img src={asset('logoTemp.jpg')} alt="Логотип ТЕМП" />
        <span>ТЕМП</span>
      </div>
      <nav>
        <ul>
          <li><Link to="/" className={cls(path === '/')}>Главная</Link></li>
          <li><Link to="/about" className={cls(path === '/about')}>О нас</Link></li>
          <li>
            <Link to="/catalog" className={cls(path === '/catalog' || /^\/machines\/\d+$/.test(path))}>Каталог</Link>
          </li>
          <li>
            {user && isCabinetPath(path) ? (
              <Link to="/" className="logout-btn" onClick={logout}>Выйти</Link>
            ) : user ? (
              <Link to={user.page}>Кабинет</Link>
            ) : (
              <Link to="/login" className={cls(path === '/login')}>Войти</Link>
            )}
          </li>
        </ul>
      </nav>
    </header>
  );
}
