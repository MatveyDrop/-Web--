import { useState } from 'react';

const PLACEHOLDER = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(
  '<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300" viewBox="0 0 400 300">' +
  '<rect width="400" height="300" fill="#EEF2F7"/>' +
  '<g fill="none" stroke="#949494" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">' +
  '<circle cx="200" cy="140" r="34"/><circle cx="200" cy="140" r="12"/></g>' +
  '<text x="200" y="230" font-family="Inter, Arial, sans-serif" font-size="22" fill="#949494" text-anchor="middle">Фото отсутствует</text></svg>'
);

// Картинка станка: если файла нет или он не загрузился, показывается заглушка.
export default function SafeImage({ src, alt, ...rest }) {
  const [failed, setFailed] = useState(false);
  const url = !src || failed ? PLACEHOLDER : src;
  return <img src={url} alt={alt} onError={() => setFailed(true)} {...rest} />;
}
