// Поле ввода с сообщением об ошибке под ним. Используется на странице входа и в форме станка.
export default function TextField({ id, error, className, ...input }) {
  return (
    <div className="field">
      <input
        id={id}
        className={error ? `${className ?? ''} is-invalid`.trim() : className}
        aria-invalid={error ? 'true' : undefined}
        {...input}
      />
      {error && <div className="invalid-feedback is-shown" role="alert">{error}</div>}
    </div>
  );
}
