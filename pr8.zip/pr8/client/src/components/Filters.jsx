import { TYPES, CONDITIONS } from '../data/seed';
import { asset } from '../utils/format';

// Управляемая форма фильтров: значения и обработчики приходят от каталога, своего состояния нет.
export default function Filters({ text, type, condition, onText, onType, onCondition, onApply, onReset }) {
  return (
    <section className="filters-section">
      <form
        className="filters-form"
        onSubmit={(e) => { e.preventDefault(); onApply(); }}
        onReset={(e) => { e.preventDefault(); onReset(); }}
      >
        <div className="search-wrapper">
          <img src={asset('icon-search.png')} alt="Поиск" className="search-icon" />
          <input
            type="text"
            placeholder="Поиск"
            aria-label="Поиск по названию и региону"
            autoComplete="off"
            value={text}
            onChange={(e) => onText(e.target.value)}
          />
        </div>

        <div className="filter-group">
          <label htmlFor="type">Тип станка</label>
          <select id="type" value={type} onChange={(e) => onType(e.target.value)}>
            <option value="">Все типы</option>
            {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
        </div>

        <div className="filter-group">
          <label htmlFor="condition">Состояние</label>
          <select id="condition" value={condition} onChange={(e) => onCondition(e.target.value)}>
            <option value="">Любое</option>
            {CONDITIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>

        <div className="filter-buttons">
          <button type="reset" className="btn-outline">Сбросить</button>
          <button type="submit" className="btn-primary">Применить</button>
        </div>
      </form>
    </section>
  );
}
