import { Navigate } from '../router';
import { useAuth } from '../context/AuthContext';

// Пускает только вошедших; если указана роль — только её. Остальных перенаправляет.
export default function ProtectedRoute({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (role && user.role !== role) return <Navigate to={user.page} />;
  return children;
}
