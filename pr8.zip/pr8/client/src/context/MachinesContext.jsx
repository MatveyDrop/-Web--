import { createContext, useCallback, useContext, useEffect, useMemo, useReducer } from 'react';
import * as api from '../api/api';

const MachinesContext = createContext(null);

const initial = { status: 'loading', items: [] };

function reducer(state, action) {
  switch (action.type) {
    case 'loaded':  return { status: 'ready', items: action.items };
    case 'failed':  return { ...state, status: 'error' };
    case 'added':   return { ...state, items: [...state.items, action.item] };
    case 'updated': return { ...state, items: state.items.map((m) => (m.id === action.item.id ? action.item : m)) };
    case 'removed': return { ...state, items: state.items.filter((m) => m.id !== action.id) };
    default:        return state;
  }
}

// Список станков нужен каталогу, странице станка, кабинетам и форме, поэтому состояние поднято в корень.
export function MachinesProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initial);

  useEffect(() => {
    let cancelled = false;
    api.fetchMachines()
      .then((items) => { if (!cancelled) dispatch({ type: 'loaded', items }); })
      .catch(() => { if (!cancelled) dispatch({ type: 'failed' }); });
    return () => { cancelled = true; };
  }, []);

  const addMachine = useCallback(async (data) => {
    const item = await api.createMachine(data);
    dispatch({ type: 'added', item });
    return item;
  }, []);

  const updateMachine = useCallback(async (id, data) => {
    const item = await api.updateMachine(id, data);
    dispatch({ type: 'updated', item });
    return item;
  }, []);

  const removeMachine = useCallback(async (id) => {
    await api.deleteMachine(id);
    dispatch({ type: 'removed', id });
  }, []);

  const value = useMemo(() => ({
    status: state.status,
    machines: state.items,
    getById: (id) => state.items.find((m) => m.id === Number(id)) ?? null,
    addMachine,
    updateMachine,
    removeMachine
  }), [state, addMachine, updateMachine, removeMachine]);

  return <MachinesContext.Provider value={value}>{children}</MachinesContext.Provider>;
}

export const useMachines = () => useContext(MachinesContext);
