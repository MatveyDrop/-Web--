import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as api from '../api/api';

const AuthContext = createContext(null);
const KEY = 'temp.session';

// Страница кабинета зависит от роли; сервер о маршрутах клиента ничего не знает.
const withPage = (user) => ({ ...user, page: user.role === 'admin' ? '/admin' : '/manager' });

function loadSession() {
  try {
    const saved = JSON.parse(sessionStorage.getItem(KEY));
    if (saved?.token && saved?.user) {
      api.setToken(saved.token);
      return withPage(saved.user);
    }
  } catch { /* повреждённые данные игнорируем */ }
  return null;
}

// Состояние «кто вошёл» нужно шапке, защищённым страницам и кабинетам, поэтому живёт в корне приложения.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(loadSession);

  const clear = useCallback(() => {
    api.setToken(null);
    try { sessionStorage.removeItem(KEY); } catch { /* ignore */ }
    setUser(null);
  }, []);

  // Если сервер ответит «не авторизован» (токен устарел, сервер перезапускали), выходим.
  useEffect(() => {
    api.onUnauthorized(clear);
    return () => api.onUnauthorized(null);
  }, [clear]);

  // При открытии сайта проверяем, что сохранённый токен всё ещё действует.
  useEffect(() => {
    if (user) api.fetchMe().catch(() => {});
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const login = useCallback(async (loginValue, password) => {
    const { token, user: found } = await api.signIn(loginValue, password);   // бросает ApiError при неверных данных
    api.setToken(token);
    try { sessionStorage.setItem(KEY, JSON.stringify({ token, user: found })); } catch { /* ignore */ }
    const full = withPage(found);
    setUser(full);
    return full;
  }, []);

  const logout = useCallback(() => {
    api.signOut().catch(() => {});
    clear();
  }, [clear]);

  const value = useMemo(() => ({ user, login, logout }), [user, login, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
