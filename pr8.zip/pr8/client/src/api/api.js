// Обращения к серверу. Все запросы идут на адрес /api: при разработке Vite перенаправляет их на сервер (vite.config.js),
// а в собранном виде сайт и API отдаются с одного адреса.

const BASE = '/api';

let token = null;
let unauthorizedHandler = null;

export const setToken = (value) => { token = value; };
export const onUnauthorized = (handler) => { unauthorizedHandler = handler; };

export class ApiError extends Error {
  constructor(message, status, fields) {
    super(message);
    this.status = status;       // 0 — сервер недоступен
    this.fields = fields ?? null;
  }
}

async function request(method, url, body) {
  const headers = {};
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers.Authorization = `Bearer ${token}`;

  let res;
  try {
    res = await fetch(BASE + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  } catch {
    throw new ApiError('Нет связи с сервером. Проверьте, что он запущен.', 0);
  }

  if (res.status === 204) return null;
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    if (res.status === 401 && token && unauthorizedHandler) unauthorizedHandler();   // сессия закончилась
    throw new ApiError(data?.error ?? 'Ошибка сервера', res.status, data?.fields);
  }
  return data;
}

export const fetchMachines = () => request('GET', '/machines');
export const createMachine = (data) => request('POST', '/machines', data);
export const updateMachine = (id, data) => request('PUT', `/machines/${id}`, data);
export const deleteMachine = (id) => request('DELETE', `/machines/${id}`);

export const signIn = (login, password) => request('POST', '/auth/login', { login, password });
export const signOut = () => request('POST', '/auth/logout');
export const fetchMe = () => request('GET', '/auth/me');
