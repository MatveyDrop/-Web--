import { TYPES, CONDITIONS } from '../data/seed';

export const asset = (name) => `${import.meta.env.BASE_URL}${name}`;

export function formatPrice(price) {
  if (price === null || price === undefined || price === '') return 'Цена договорная';
  return new Intl.NumberFormat('ru-RU').format(price).replace(/ /g, ' ') + ' ₽';
}

export function formatDate(iso) {
  const [y, m, d] = String(iso).split('-');
  return `${d}.${m}.${y}`;
}

export const typeLabel = (value) => TYPES.find((t) => t.value === value)?.label ?? value;
export const conditionLabel = (value) => CONDITIONS.find((c) => c.value === value)?.label ?? value;

export function todayISO() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}
