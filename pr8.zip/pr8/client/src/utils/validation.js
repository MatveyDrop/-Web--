// Чистые функции проверки: получают значение, возвращают текст ошибки или пустую строку.
import { TYPES } from '../data/seed';

export const required = (v) => (String(v).trim() === '' ? 'Поле обязательно для заполнения' : '');
export const minLength = (n) => (v) => (String(v).trim().length < n ? `Минимум ${n} символа(ов)` : '');

export const email = (v) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v).trim()) ? '' : 'Введите корректный email, например name@example.com';

export function phone(v) {
  const digits = String(v).replace(/\D/g, '');
  const ok = /^[\d\s()+\-]+$/.test(v) && digits.length === 11 && (digits[0] === '7' || digits[0] === '8');
  return ok ? '' : 'Введите телефон в формате +7 (999) 123-45-67';
}

export function positiveNumber(v) {
  const n = Number(v);
  if (String(v).trim() === '' || Number.isNaN(n)) return 'Введите цену числом';
  if (n <= 0) return 'Цена должна быть больше нуля';
  if (n > 1000000000) return 'Слишком большая цена';
  if (!Number.isInteger(n)) return 'Цена указывается в целых рублях';
  return '';
}

export const knownType = (v) =>
  TYPES.some((t) => t.label.toLowerCase() === String(v).trim().toLowerCase()) ? '' : 'Выберите тип из списка';

export const findType = (label) => TYPES.find((t) => t.label.toLowerCase() === String(label).trim().toLowerCase());

export function check(value, rules) {
  for (const rule of rules) {
    const message = rule(value);
    if (message) return message;
  }
  return '';
}

export const loginRules = {
  login: [required, minLength(3)],
  password: [required, minLength(6)]
};

export const machineRules = {
  title: [required, minLength(3)],
  type: [required, knownType],
  region: [required, minLength(2)],
  price: [positiveNumber],
  email: [required, email],
  phone: [required, phone]
};

// Возвращает объект { поле: сообщение } только для полей с ошибками.
export function validateForm(values, rules, skip = () => false) {
  const errors = {};
  Object.keys(rules).forEach((field) => {
    if (skip(field)) return;
    const message = check(values[field], rules[field]);
    if (message) errors[field] = message;
  });
  return errors;
}
