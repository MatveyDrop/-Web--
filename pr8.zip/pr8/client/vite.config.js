import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// При разработке запросы к /api и /uploads уходят на сервер (папка server, порт 3001).
export default defineConfig({
  plugins: [react()],
  base: './',
  server: {
    proxy: {
      '/api': 'http://localhost:3001',
      '/uploads': 'http://localhost:3001'
    }
  }
});
