# ТЕМП — сайт по продаже станков

Клиентская часть на React + Vite. Данные пока берутся из заглушки (`src/api/api.js`), серверная часть появится в лабе 7.

## Запуск

```
npm install
npm run dev        # разработка, http://localhost:5173
npm run build      # сборка в папку dist
npm run preview    # просмотр собранной версии
```

## Вход для сотрудников

| Роль | Логин | Пароль |
|------|-------|--------|
| Администратор | admin | admin123 |
| Менеджер | manager | manager123 |

## Структура

```
src/
  api/          заглушка сервера (промисы, localStorage)
  components/   Header, Footer, Layout, MachineCard, Filters, Pagination, TextField, ...
  context/      AuthContext (кто вошёл), MachinesContext (список станков)
  data/         справочники и стартовые данные
  pages/        Home, About, Catalog, MachinePage, Login, Dashboard, MachineEditor
  utils/        форматирование, проверка форм, уменьшение фото
  router.jsx    маршрутизатор на хэше адреса
public/         картинки и иконки
```
