import Layout from '../components/Layout';
import { Link } from '../router';
import { useAuth } from '../context/AuthContext';
import { useMachines } from '../context/MachinesContext';
import { asset, formatDate } from '../utils/format';

// Один компонент на оба кабинета: администратор видит все объявления, менеджер — только свои.
export default function Dashboard({ role }) {
  const { user } = useAuth();
  const { machines, status, removeMachine } = useMachines();
  const rows = role === 'admin' ? machines : machines.filter((m) => m.author === user.name);

  const remove = (m) => {
    if (window.confirm(`Удалить объявление «${m.title}»?`)) removeMachine(m.id);
  };

  return (
    <Layout title={role === 'admin' ? 'Кабинет администратора' : 'Кабинет менеджера'}>
      <div className="dashboard-header">
        <h1>Добро пожаловать, {user.name}</h1>
        <Link to="/machines/new" className="add-link">Добавить станок</Link>
      </div>

      <div className="table-scroll">
        <table className="dashboard-table">
          <thead>
            <tr>
              <th>Модель станка</th>
              <th>Автор</th>
              <th>Дата</th>
              <th>Местонахождение</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {status !== 'ready' && (
              <tr><td colSpan="5" className="empty-state">Загрузка…</td></tr>
            )}
            {status === 'ready' && rows.length === 0 && (
              <tr><td colSpan="5" className="empty-state">Объявлений пока нет. Нажмите «Добавить станок».</td></tr>
            )}
            {status === 'ready' && rows.map((m) => (
              <tr key={m.id}>
                <td>{m.title}</td>
                <td>{m.author}</td>
                <td>{formatDate(m.createdAt)}</td>
                <td>{m.region}</td>
                <td>
                  <div className="action-buttons">
                    <Link to={`/machines/${m.id}/edit`} className="btn-icon" title="Редактировать">
                      <img src={asset('icon-edit.png')} alt="Редактировать" />
                    </Link>
                    <button type="button" className="btn-icon" title="Удалить" onClick={() => remove(m)}>
                      <img src={asset('icon-delete.png')} alt="Удалить" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
}
