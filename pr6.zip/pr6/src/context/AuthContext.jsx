import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { signIn } from '../api/api';

const AuthContext = createContext(null);
const KEY = 'temp.session';

function loadSession() {
  try { return JSON.parse(sessionStorage.getItem(KEY)); } catch { return null; }
}

// Состояние «кто вошёл» нужно шапке, защищённым страницам и кабинетам, поэтому живёт в корне приложения.
export function AuthProvider({ children }) {
  const [user, setUser] = useState(loadSession);

  const login = useCallback(async (loginValue, password) => {
    const found = await signIn(loginValue, password);   // бросает ошибку при неверных данных
    try { sessionStorage.setItem(KEY, JSON.stringify(found)); } catch { /* ignore */ }
    setUser(found);
    return found;
  }, []);

  const logout = useCallback(() => {
    try { sessionStorage.removeItem(KEY); } catch { /* ignore */ }
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, login, logout }), [user, login, logout]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
