// Заглушка серверного API. Функции асинхронные и возвращают промисы, как настоящие запросы,
// поэтому компоненты уже сейчас работают с состояниями «загрузка / готово / ошибка».
// В лабе 7 тела функций заменятся на fetch('/api/...').
import { SEED_MACHINES, USERS } from '../data/seed';

const KEY = 'temp.machines';
const DELAY = 150;

const wait = (value) => new Promise((resolve) => setTimeout(() => resolve(value), DELAY));

function readAll() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    if (Array.isArray(saved)) return saved;
  } catch { /* хранилище недоступно или повреждено */ }
  return structuredClone(SEED_MACHINES);
}

function writeAll(list) {
  try { localStorage.setItem(KEY, JSON.stringify(list)); } catch { /* квота или приватный режим */ }
}

export async function fetchMachines() {
  return wait(readAll());
}

export async function createMachine(data) {
  const list = readAll();
  const id = list.reduce((max, m) => Math.max(max, m.id), 0) + 1;
  const machine = { specs: [], description: '', ...data, id };
  writeAll([...list, machine]);
  return wait(machine);
}

export async function patchMachine(id, data) {
  const list = readAll();
  const next = list.map((m) => (m.id === id ? { ...m, ...data } : m));
  writeAll(next);
  return wait(next.find((m) => m.id === id));
}

export async function deleteMachine(id) {
  writeAll(readAll().filter((m) => m.id !== id));
  return wait(true);
}

export async function signIn(login, password) {
  const user = USERS.find((u) => u.login === login && u.password === password);
  if (!user) {
    await wait();
    throw new Error('Неверный логин или пароль');
  }
  const { password: _omit, ...safe } = user;      // пароль дальше не передаётся
  return wait(safe);
}
